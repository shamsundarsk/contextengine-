import {
  getBranches,
  getCommits,
  getStats,
  checkout,
  branch,
  SessionStats,
  Branch,
  Commit,
} from '@context-engine/core';

export function getSessionData(sessionId: string) {
  const stats: SessionStats = getStats(sessionId);
  const branches: Branch[] = getBranches(sessionId);
  const commits: Commit[] = getCommits(sessionId);

  return {
    stats,
    branches,
    commits,
  };
}

export function executeCheckout(sessionId: string, commitId: string) {
  checkout(sessionId, commitId);
}

export function executeBranch(sessionId: string, name: string) {
  branch(sessionId, name);
}
