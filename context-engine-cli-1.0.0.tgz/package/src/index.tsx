import React, { useEffect, useState } from 'react';
import { render, Box, Text, useApp } from 'ink';
import { Command } from 'commander';
import dotenv from 'dotenv';
import { getSessionData, executeCheckout, executeBranch } from './api.js';
import { StatsBar } from './components/StatsBar.js';
import { BranchList } from './components/BranchList.js';
import { CommitLog } from './components/CommitLog.js';

dotenv.config();

interface WatchViewProps {
  sessionId: string;
}

const WatchView: React.FC<WatchViewProps> = ({ sessionId }) => {
  const [data, setData] = useState(() => getSessionData(sessionId));
  const { exit } = useApp();

  useEffect(() => {
    const timer = setInterval(() => {
      try {
        const nextData = getSessionData(sessionId);
        setData(nextData);
      } catch (err) {
        // Non-fatal
      }
    }, 1500);

    return () => clearInterval(timer);
  }, [sessionId]);

  return (
    <Box flexDirection="column" padding={1} width="100%">
      <StatsBar stats={data.stats} />
      <Box flexDirection="row" marginTop={1} gap={1}>
        <BranchList branches={data.branches} activeBranch={data.stats.activeBranch} />
        <CommitLog commits={data.commits} />
      </Box>
      <Box marginTop={1}>
        <Text dimColor>Press Ctrl+C to exit watch mode. Refreshing every 1.5s.</Text>
      </Box>
    </Box>
  );
};

const program = new Command();

program
  .name('context-engine')
  .description('Context Engine CLI & Watcher Tool')
  .version('1.0.0');

program
  .command('watch')
  .description('Live interactive terminal UI watching context graph & session metrics')
  .option('-s, --session <id>', 'Session ID to watch', 'default_session')
  .action((options) => {
    const sessionId = options.session || 'default_session';
    render(<WatchView sessionId={sessionId} />);
  });

program
  .command('checkout <commitId>')
  .description('Checkout a specific commit ID')
  .option('-s, --session <id>', 'Session ID', 'default_session')
  .action((commitId, options) => {
    const sessionId = options.session || 'default_session';
    try {
      executeCheckout(sessionId, commitId);
      console.log(`Successfully checked out commit '${commitId}' for session '${sessionId}'.`);
    } catch (err: any) {
      console.error(`Checkout failed: ${err.message}`);
      process.exit(1);
    }
  });

program
  .command('branch <name>')
  .description('Create or switch to a branch')
  .option('-s, --session <id>', 'Session ID', 'default_session')
  .action((name, options) => {
    const sessionId = options.session || 'default_session';
    try {
      executeBranch(sessionId, name);
      console.log(`Successfully created / switched to branch '${name}' for session '${sessionId}'.`);
    } catch (err: any) {
      console.error(`Branch failed: ${err.message}`);
      process.exit(1);
    }
  });

program.parse(process.argv);
