import {
  commit as coreCommit,
  branch as coreBranch,
  checkout as coreCheckout,
  merge as coreMerge,
  getCommits,
  getActiveBranch,
} from '@context-engine/core';

export async function handleRecall(sessionId: string, query: string, scope: 'branch' | 'all' = 'all') {
  const activeBranch = getActiveBranch(sessionId);
  const targetBranch = scope === 'branch' ? activeBranch.name : undefined;
  const commits = getCommits(sessionId, targetBranch);

  const queryLower = query.toLowerCase();
  const matchedCommits = commits.filter((c) => {
    const topicMatch = c.topic_label.toLowerCase().includes(queryLower);
    const reasonMatch = c.reason_log.toLowerCase().includes(queryLower);
    const chunkMatch = (c.chunks || []).some((ch) => ch.content.toLowerCase().includes(queryLower));
    return topicMatch || reasonMatch || chunkMatch;
  });

  if (matchedCommits.length === 0) {
    return {
      content: [
        {
          type: 'text',
          text: `No commits matching query '${query}' found in ${scope} scope. Total commits checked: ${commits.length}.`,
        },
      ],
    };
  }

  const resultsFormatted = matchedCommits
    .map((c) => {
      const kept = (c.chunks || []).filter((ch) => ch.label === 'keep_verbatim').map((ch) => ch.content);
      return `[Commit ${c.id}] Branch: ${c.branch} | Topic: ${c.topic_label}\nReason: ${c.reason_log}\nKept Facts:\n${kept.join('\n')}`;
    })
    .join('\n\n---\n\n');

  return {
    content: [
      {
        type: 'text',
        text: `Found ${matchedCommits.length} matching commits for query '${query}':\n\n${resultsFormatted}`,
      },
    ],
  };
}

export async function handleCommit(
  sessionId: string,
  topic: string,
  summary: string,
  kept_refs: string[] = []
) {
  const activeBranch = getActiveBranch(sessionId);

  const chunks = [
    ...kept_refs.map((ref) => ({
      content: ref,
      label: 'keep_verbatim' as const,
      source_ref: 'mcp_kept_ref',
    })),
    {
      content: summary,
      label: 'summarize' as const,
      source_ref: 'mcp_summary',
    },
  ];

  const newCommit = coreCommit(sessionId, activeBranch.name, topic, summary, chunks);

  return {
    content: [
      {
        type: 'text',
        text: `Successfully created Commit ${newCommit.id} on branch '${activeBranch.name}'.\nTopic: ${topic}\nKept Refs: ${kept_refs.length}\nSummary: ${summary}`,
      },
    ],
  };
}

export async function handleBranch(sessionId: string, name: string, from_commit?: string) {
  const newBranch = coreBranch(sessionId, name, from_commit);
  return {
    content: [
      {
        type: 'text',
        text: `Switched to branch '${newBranch.name}'. Head commit is set to: ${newBranch.head_commit_id || 'root'}.`,
      },
    ],
  };
}

export async function handleMerge(sessionId: string, source_branch: string, target_branch: string = 'main') {
  const res = coreMerge(sessionId, source_branch, target_branch);

  if (!res.success) {
    return {
      isError: true,
      content: [
        {
          type: 'text',
          text: `CONFLICT DETECTED! Merge from '${source_branch}' into '${target_branch}' failed.\nConflict ID: ${res.conflict?.id}\nDescription: ${res.conflict?.description}`,
        },
      ],
    };
  }

  return {
    content: [
      {
        type: 'text',
        text: `Successfully merged '${source_branch}' into '${target_branch}'. Merge Commit ID: ${res.mergedCommitId}`,
      },
    ],
  };
}

export async function handleCheckout(sessionId: string, commit_id: string) {
  try {
    coreCheckout(sessionId, commit_id);
    return {
      content: [
        {
          type: 'text',
          text: `Successfully checked out commit ${commit_id}.`,
        },
      ],
    };
  } catch (err: any) {
    return {
      isError: true,
      content: [
        {
          type: 'text',
          text: `Checkout failed: ${err.message}`,
        },
      ],
    };
  }
}
