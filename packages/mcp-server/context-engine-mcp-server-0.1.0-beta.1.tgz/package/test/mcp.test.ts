import { describe, it, expect, beforeEach } from 'vitest';
import Database from 'better-sqlite3';
import { setDatabase } from '@context-engine/core';
import { handleCommit, handleRecall, handleBranch, handleMerge, handleCheckout } from '../src/tools.js';

describe('MCP Server Tools', () => {
  const sessionId = 'test_mcp_session';

  beforeEach(() => {
    const db = new Database(':memory:');
    setDatabase(db);
  });

  it('handles commit and recall tool calls', async () => {
    const commitRes = await handleCommit(
      sessionId,
      'Auth Spec',
      'Configured JWT token expiration',
      ['JWT secret stored in ENV', 'Tokens expire in 24h']
    );

    expect(commitRes.content[0].text).toContain('Auth Spec');

    const recallRes = await handleRecall(sessionId, 'JWT');
    expect(recallRes.content[0].text).toContain('JWT secret stored in ENV');
  });

  it('handles branching, merging, and checkout tool calls', async () => {
    const b1 = await handleBranch(sessionId, 'feature-cache');
    expect(b1.content[0].text).toContain('feature-cache');

    await handleCommit(sessionId, 'Caching', 'Added Redis cache layer', ['Redis port 6379']);

    const mergeRes = await handleMerge(sessionId, 'feature-cache', 'main');
    expect(mergeRes.content[0].text).toContain('Successfully merged');
  });
});
