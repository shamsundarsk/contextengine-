import crypto from 'crypto';
import { getDatabase } from './store/db.js';
import { Chunk } from './store/types.js';

/**
 * Generates SHA-256 hash key for input chunks.
 */
function hashChunks(chunks: Chunk[]): string {
  const combined = chunks.map((c) => `${c.id}:${c.content}`).join('||');
  return crypto.createHash('sha256').update(combined).digest('hex');
}

/**
 * Fallback extractive summary when LLM API keys are not provided or API calls fail.
 */
function fallbackSummarize(chunks: Chunk[]): string {
  const text = chunks.map((c) => c.content).join('\n');
  const sentences = text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (sentences.length <= 2) {
    return text;
  }

  // Pick first sentence, last sentence, and any sentence with key action words
  const keySentences: string[] = [sentences[0]];
  for (let i = 1; i < sentences.length - 1; i++) {
    if (/\b(decided|must|created|updated|error|fix|used|endpoint|select|add|remove|config)\b/i.test(sentences[i])) {
      if (!keySentences.includes(sentences[i])) {
        keySentences.push(sentences[i]);
      }
    }
  }
  if (!keySentences.includes(sentences[sentences.length - 1])) {
    keySentences.push(sentences[sentences.length - 1]);
  }

  return keySentences.slice(0, 3).join(' ');
}

/**
 * Summarizes an array of 'summarize'-tier chunks using a cheap model or cached result.
 */
export async function summarize(chunks: Chunk[], modelOverride?: string): Promise<string> {
  if (!chunks || chunks.length === 0) return '';

  const hashKey = hashChunks(chunks);
  const db = getDatabase();

  // 1. Check cache first
  try {
    const cachedRow = db.prepare('SELECT summary FROM summary_cache WHERE hash = ?').get(hashKey) as { summary: string } | undefined;
    if (cachedRow?.summary) {
      return cachedRow.summary;
    }
  } catch (err) {
    // Cache lookup non-fatal
  }

  const model = modelOverride || process.env.SUMMARIZER_MODEL || 'gpt-4o-mini';
  const combinedContent = chunks.map((c) => c.content).join('\n---\n');
  let summaryResult = '';

  // 2. Attempt API Call if keys exist
  try {
    if (model.includes('claude') && process.env.ANTHROPIC_API_KEY) {
      const Anthropic = (await import('@anthropic-ai/sdk')).default;
      const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
      const resp = await client.messages.create({
        model,
        max_tokens: 250,
        system: 'Summarize the following context into 1-2 concise sentences, focusing on decisions, entities, and actions.',
        messages: [{ role: 'user', content: combinedContent }],
      });
      const firstBlock = resp.content[0];
      if (firstBlock && firstBlock.type === 'text') {
        summaryResult = firstBlock.text.trim();
      }
    } else if (process.env.OPENAI_API_KEY) {
      const endpoint = process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1';
      const resp = await fetch(`${endpoint}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model,
          messages: [
            {
              role: 'system',
              content: 'Summarize the following context into 1-2 concise sentences, focusing on decisions, entities, and actions.',
            },
            { role: 'user', content: combinedContent },
          ],
          max_tokens: 250,
        }),
      });
      if (resp.ok) {
        const json = await resp.json();
        summaryResult = json.choices?.[0]?.message?.content?.trim();
      }
    }
  } catch (err) {
    console.warn('[Core:Summarizer] LLM summary call failed or offline, falling back to extractive summary.');
  }

  // 3. Fallback if no LLM output generated
  if (!summaryResult) {
    summaryResult = fallbackSummarize(chunks);
  }

  // 4. Cache summary result
  try {
    db.prepare('INSERT OR REPLACE INTO summary_cache (hash, summary, timestamp) VALUES (?, ?, ?)').run(
      hashKey,
      summaryResult,
      Date.now()
    );
  } catch (err) {
    // Non-fatal
  }

  return summaryResult;
}
